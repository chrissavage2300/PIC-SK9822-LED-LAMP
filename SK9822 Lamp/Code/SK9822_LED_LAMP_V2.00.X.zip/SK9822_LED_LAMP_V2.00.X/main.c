 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.0
*/

/*
 * NOTE: Use low speed programming.
*/
#include "mcc_generated_files/system/system.h"
#include "xc.h"
#include <stdio.h>
//Brightness Value Frame Math
const uint8_t BRIGHTNESS_VALUE = 2;//0 to 31
const uint8_t BRIGHTNESS_START_BITS = 224; // 0b11100000
uint8_t BRIGHTNESS_FRAME = BRIGHTNESS_START_BITS | BRIGHTNESS_VALUE;
_Bool LowBatteryFlag;
unsigned int BatteryVoltageRAW;


void BatteryGoodColors(void){
        SPI1_Initialize();
        SPI1_Open(MSSP1_DEFAULT);
        SPI1_ByteExchange(0x00);
        SPI1_ByteExchange(0x00);
        SPI1_ByteExchange(0x00);
        SPI1_ByteExchange(0x00);
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED1
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(204);//Red
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED2
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(24);//Green
        SPI1_ByteExchange(196);//Red
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED3
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(32);//Green
        SPI1_ByteExchange(128);//Red
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED4
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(64);//Green
        SPI1_ByteExchange(0);//Red
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED5
        SPI1_ByteExchange(16);//blue
        SPI1_ByteExchange(64);//Green
        SPI1_ByteExchange(0);//Red
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED6
        SPI1_ByteExchange(130);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(0);//Red 
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED6
        SPI1_ByteExchange(64);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(64);//Red  
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED7
        SPI1_ByteExchange(32);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(196);//Red      
        SPI1_ByteExchange(0xFF);//End Frame
        SPI1_ByteExchange(0xFF);//End Frame        
        SPI1_ByteExchange(0xFF);//End Frame
        SPI1_ByteExchange(0xFF);//End Frame    
}
void BatteryBadColors(void){
        SPI1_Initialize();
        SPI1_Open(MSSP1_DEFAULT);
        SPI1_ByteExchange(0x00);
        SPI1_ByteExchange(0x00);
        SPI1_ByteExchange(0x00);
        SPI1_ByteExchange(0x00);
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED1
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(204);//Red
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED2
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(0);//Red
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED3
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(0);//Red
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED4
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(0);//Red
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED5
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(0);//Red
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED6
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(0);//Red 
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED6
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(0);//Red  
        SPI1_ByteExchange(BRIGHTNESS_FRAME);//LED7
        SPI1_ByteExchange(0);//blue
        SPI1_ByteExchange(0);//Green
        SPI1_ByteExchange(0);//Red      
        SPI1_ByteExchange(0xFF);//End Frame
        SPI1_ByteExchange(0xFF);//End Frame        
        SPI1_ByteExchange(0xFF);//End Frame
        SPI1_ByteExchange(0xFF);//End Frame    
}


/*
    Main application
 *
 *  //PMD3 = 0xD7; turn on FVR
*/



int main(void)
{
    SYSTEM_Initialize();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 

    // Disable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptDisable(); 

    LED_ENABLE_SetLow();//turn off LEDs
    LowBatteryFlag=0;
    while(1)
    {   
        if (TILT_SWITCH_GetValue()==1){//switch is open
            LED_ENABLE_SetLow();//turn off outputs
            SLEEP();
        }//end Tilt Switch Check
        
       BatteryVoltageRAW=ADCC_GetSingleConversion (BatteryVoltage);
       //expected value for full battery:1665, 4.066vdc
       //Battery voltage is halved due to resistor divider
       //Set Low Battery for 3VDC, or 1229 counts
       //BatteryVoltageRAW=ADCC_GetConversionResult;
        
       if (BatteryVoltageRAW<=1229){//Low battery check. 3VDC or 1229 counts.
           LowBatteryFlag=1;
       }
       if (BatteryVoltageRAW>1229){//Battery Good Check. 3VDC or 1229 counts.
           LowBatteryFlag=0;
       }
              
       
       
       if (LowBatteryFlag==0){
           BatteryGoodColors();
        }//End Low Battery Check, Status = GOOD.
        
       if (LowBatteryFlag==1){
           BatteryBadColors();
        }//End Low Battery Check, Status = GOOD.        
        
        
    }    
}